function [y,z]=LP_solve_full_ABL( ...
    n_sample,...
    scaled_M,...
    scaled_factors,...
    rho,...
    db,...
    options,...
    dL,...
    b_ind)

length_b_ind=length(b_ind); % number of known labels
number_of_variables=2*(n_sample+1)+2*length_b_ind; % number of variables (original y's z's + absolute values of y's z's)
LP_A=zeros(n_sample+1+number_of_variables,number_of_variables);
LP_b=zeros(n_sample+1+number_of_variables,1);

lb=zeros(number_of_variables,1);
ub=zeros(number_of_variables,1);
lb(1:n_sample+1+length_b_ind)=-Inf; % y's z's can be +/-
ub(1:end)=Inf; % abs(y)'s abs(z)'s >= 0

counter=0;
add_row=0;

%% ========keep in mind=========
% 1. define additional variables for variables with absolute values
%% =============================

for current_sample_number=1:n_sample
    if ismember(current_sample_number,b_ind) % both y and z exist
        counter=counter+1; 
               
        % y_i+L_{ii} - abs(\sum_{j \neq i}{s_i/s_j*M_ij}) >= rho
        % -y_i + abs(scaled_factors(current_sample_number,end))*abs(z_i) <=
        % L_{ii}-abs(\sum_{j \neq i}{s_i/s_j*M_ij}) -rho
        LP_A(current_sample_number,current_sample_number)=-1;
        LP_A(current_sample_number,n_sample+1+length_b_ind+n_sample+1+counter)=...
            abs(scaled_factors(current_sample_number,end));
        remaning_idx=1:n_sample+1;
        remaning_idx([current_sample_number n_sample+1])=[];
        LP_b(current_sample_number)=dL(current_sample_number,current_sample_number)...
            -sum(abs(scaled_M(current_sample_number,remaning_idx)))...
            -rho;
        
        % y_i - abs(y_i) <= 0
        % -y_i - abs(y_i) <= 0
        % z_i - abs(z_i) <= 0
        % -z_i - abs(z_i) <= 0
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,current_sample_number)=1;
        LP_A(n_sample+1+add_row,current_sample_number+n_sample+1+length_b_ind)=-1;
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,current_sample_number)=-1;
        LP_A(n_sample+1+add_row,current_sample_number+n_sample+1+length_b_ind)=-1;
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,n_sample+1+counter)=1;
        LP_A(n_sample+1+add_row,n_sample+1+counter+n_sample+1+length_b_ind)=-1;
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,n_sample+1+counter)=-1;
        LP_A(n_sample+1+add_row,n_sample+1+counter+n_sample+1+length_b_ind)=-1;
        
    else % only y exists
 
        % y_i+L_{ii} - abs(\sum_{j \neq i}{s_i/s_j*M_ij}) >= rho
        % -y_i <= L_{ii}-abs(\sum_{j \neq i}{s_i/s_j*M_ij}) -rho
        
        LP_A(current_sample_number,current_sample_number)=-1;
%         LP_A(current_sample_number,n_sample+1+length_b_ind+n_sample+1+counter)=...
%             abs(scaled_factors(current_sample_number,end));
        remaning_idx=1:n_sample+1;
        remaning_idx(current_sample_number)=[];
        LP_b(current_sample_number)=dL(current_sample_number,current_sample_number)...
            -sum(abs(scaled_M(current_sample_number,remaning_idx)))...
            -rho;
   
        % y_i - abs(y_i) <= 0
        % -y_i - abs(y_i) <= 0
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,current_sample_number)=1;
        LP_A(n_sample+1+add_row,current_sample_number+n_sample+1+length_b_ind)=-1;
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,current_sample_number)=-1;
        LP_A(n_sample+1+add_row,current_sample_number+n_sample+1+length_b_ind)=-1;
%         LP_A(n_sample+1+4*(current_sample_number-1)+3,n_sample+1+counter)=1;
%         LP_A(n_sample+1+4*(current_sample_number-1)+3,n_sample+1+counter+n_sample+1+length_b_ind)=-1;
%         LP_A(n_sample+1+4*(current_sample_number-1)+4,n_sample+1+counter)=-1;
%         LP_A(n_sample+1+4*(current_sample_number-1)+4,n_sample+1+counter+n_sample+1+length_b_ind)=-1;

    end 
end

        % y_i+L_{ii} - abs(\sum_{j \neq i}{s_i/s_j*M_ij}) >= rho
        % -y_i + \sum_{j\neq i}{abs(scaled_M(end,b_ind))} <= L_{ii}-rho
        
        LP_A(n_sample+1,n_sample+1)=-1;
        LP_A(n_sample+1,n_sample+1+length_b_ind+n_sample+1+1:end)=...
            abs(scaled_factors(end,b_ind));
        
%         remaning_idx=1:n_sample+1;
%         remaning_idx(current_sample_number)=[];
        LP_b(n_sample+1)=dL(n_sample+1,n_sample+1)-rho;
 
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,n_sample+1)=1;
        LP_A(n_sample+1+add_row,n_sample+1+n_sample+1+length_b_ind)=-1;
        add_row=add_row+1;
        LP_A(n_sample+1+add_row,n_sample+1)=-1;
        LP_A(n_sample+1+add_row,n_sample+1+n_sample+1+length_b_ind)=-1;

% LP_A(1,1)=sign_vec*sign(scaled_factors(i,n_sample+1))*abs(scaled_factors(i,n_sample+1));
% LP_A(2,1)=sign_vec*sign(scaled_factors(n_sample+1,i))*abs(scaled_factors(n_sample+1,i));
% remaning_idx=1:n_sample+1;
% remaning_idx([i n_sample+1])=[];
% LP_b(1)=scaled_M(i,i)-y(i)-sum(abs(scaled_M(i,remaning_idx)))-rho;
% remaning_idx=1:n_sample;
% remaning_idx(i)=[];
% LP_b(2)=scaled_M(n_sample+1,n_sample+1)-y(n_sample+1)-sum(abs(scaled_M(n_sample+1,remaning_idx)))-rho;

try
    s_k = linprog([ones(1,n_sample+1) db' zeros(1,n_sample+1+length_b_ind)],...
        LP_A,LP_b,...
        [],[],...
        lb,ub,options);
    if isempty(s_k)
        s_k=Inf;
    end
catch
    s_k=Inf;
end
s_k=s_k(1:n_sample+1+length_b_ind);
y=s_k(1:n_sample+1);
z=s_k(n_sample+1+1:end);
end

